package com.example.ubberApp.ubberApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UbberAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(UbberAppApplication.class, args);
	}

}
